package mx.edu.itses.itb.MetodosNumericos.services;

import java.util.ArrayList;
import mx.edu.itses.itb.MetodosNumericos.domain.ReglaCramer;

public interface UnidadIIIService {


    public ReglaCramer AlgoritmoReglaCramer(ReglaCramer modelCramer);
    
}
