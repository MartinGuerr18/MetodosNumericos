package mx.edu.itses.itb.MetodosNumericos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetodosNumericosApplicationTests {

	@Test
	void contextLoads() {
	}

}
